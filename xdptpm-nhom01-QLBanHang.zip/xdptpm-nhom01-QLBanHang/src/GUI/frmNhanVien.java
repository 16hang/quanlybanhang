/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NhanVien;
import Utils.Bam;
import Utils.Conn;
import Utils.KTSdt;
import Utils.KTSo;
import Utils.KichThuocData;
import Utils.KtEmail;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author asus
 */
public class frmNhanVien extends javax.swing.JPanel {

    /**
     * Creates new form frmNhanVien
     */
    Bam pw = new Bam();
    KTSdt ktphone = new KTSdt();
    KtEmail ktemail = new KtEmail();
    KTSo ktso = new KTSo();
    private DefaultTableModel defaultTableModel;
    NhanVien sp = new NhanVien();
    KichThuocData ktmax = new KichThuocData();
    int index = -1;
    ArrayList<NhanVien> listNV = new ArrayList<>();
    ArrayList<NhanVien> listTK = new ArrayList<>();

    ArrayList<NhanVien> listNVHD = new ArrayList<>();

    public frmNhanVien(String tenNV) {
        initComponents();
        loadFile();
        getData(listNV);
        jlbXinChao.setText("Xin chào, " + tenNV);
    }

    public frmNhanVien() {
        initComponents();
    }

    public void reset() {

        // trả lại các ô trống
        txtMaNV.setText("");
        txtTenNV.setText("");
        txtEmail.setText("");
        txtSDT.setText("");
        txtDiaChi.setText("");
        pwMatkhau.setText("");
        txtMaNV.setEditable(true);
        pwMatkhau.setEditable(true);
        listNV.clear();
        loadFile();
        getData(listNV);
        index = -1;
    }

    //Hàm so sánh kích thước nhập vào với csdl
    public boolean kt() {
        boolean kq = true;
        if (txtDiaChi.getText().length() > ktmax.layKichThuoc("nhanvien", "diachi")) {
            JOptionPane.showMessageDialog(this, "Địa chỉ không được nhập quá " + ktmax.layKichThuoc("nhanvien", "diachi") + " kí tự!");
            kq = false;
        } else {
            if (txtEmail.getText().length() > ktmax.layKichThuoc("nhanvien", "email")) {
                JOptionPane.showMessageDialog(this, "Email không được nhập quá " + ktmax.layKichThuoc("nhanvien", "email") + " kí tự!");
                kq = false;
            } else {
                if (txtMaNV.getText().length() > ktmax.layKichThuoc("nhanvien", "manv")) {
                    JOptionPane.showMessageDialog(this, "Mã nhân viên không được nhập quá " + ktmax.layKichThuoc("nhanvien", "manv") + " kí tự!");
                    kq = false;
                } else {
                    if (txtSDT.getText().length() > ktmax.layKichThuoc("nhanvien", "sdt")) {
                        JOptionPane.showMessageDialog(this, "Số điện thoại không được nhập quá " + ktmax.layKichThuoc("nhanvien", "sdt") + " kí tự!");
                        kq = false;
                    } else {
                        if (txtTenNV.getText().length() > ktmax.layKichThuoc("nhanvien", "tennv")) {
                            JOptionPane.showMessageDialog(this, "Tên nhân viên không được nhập quá " + ktmax.layKichThuoc("nhanvien", "tennv") + " kí tự!");
                            kq = false;
                        } else {
                            kq = true;
                        }
                    }
                }
            }
        }
        return kq;
    }

    //Hàm thêm 1 nv vào csdl
    public void them(String maNV, String tenNV, String gioiTinh, String sdt, String email, String diaChi, String trangThai, String matKhau, String quyen) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String insert = "INSERT INTO NhanVien VALUES('" + maNV + "', N'" + tenNV + "', N'" + gioiTinh + "', '" + sdt + "', '" + email + "', N'" + diaChi + "', N'" + trangThai + "', '" + matKhau + "', N'" + quyen + "')";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(insert);
            rs = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Thêm nhân viên thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Thêm nhân viên không thành công");
            e.printStackTrace();
        }
    }

    //Hàm tìm kiếm(chọn có điều kiện)
    public void timkiem(String caicantim) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from Nhanvien where TenNV like N'%" + caicantim + "%' OR Email like '%" + caicantim + "%'  ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
                listTK.add(nv);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }
    //Hàm sửa 1 nv trong csdl

    public void sua(String maNV, String tenNV, String gioiTinh, String sdt, String email, String diaChi, String trangThai, String quyen) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String update = "Update NhanVien SET TenNV= N'" + tenNV + "', GioiTinh=N'" + gioiTinh + "', SDT='" + sdt + "', Email ='" + email + "', DiaChi=N'" + diaChi + "', TrangThai=N'" + trangThai + "' , Quyen=N'" + quyen + "' where MaNV= '" + maNV + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(update);
            rs = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Sửa nhân viên thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sửa nhân viên không thành công");
            e.printStackTrace();
        }
    }

    //Hàm xóa một nhân vivinra khỏi csdl
    public void xoa(String caicanxoa) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            String query = "delete from NhanVien where MaNV = '" + caicanxoa + "'   ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Xóa nhân viên thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Xóa nhân viên không thành công");
        }
    }

    //Hàm lấy ds nv từ csdl
    public ArrayList<NhanVien> loadFile() {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from Nhanvien";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
                listNV.add(nv);
            }
            conn.close();
            return listNV;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
            return null;
        }

    }

    //Hàm hiển thị ds nhân viên ra bảng
    private void getData(ArrayList<NhanVien> listNV) {
        defaultTableModel = new DefaultTableModel();
        defaultTableModel.addColumn("Mã nhân viên");
        defaultTableModel.addColumn("Tên nhân viên");
        defaultTableModel.addColumn("SĐT");
        defaultTableModel.addColumn("Email");
        defaultTableModel.addColumn("Giới tính");
        defaultTableModel.addColumn("Địa chỉ");
        defaultTableModel.addColumn("Nhóm");
        defaultTableModel.addColumn("Trạng thái");

        for (NhanVien obj : listNV) {
            Vector vector = new Vector();
            vector.add(obj.getMaNV());
            vector.add(obj.getTenNV());
            vector.add(obj.getSdt());
            vector.add(obj.getEmail());
            vector.add(obj.getGioiTinh());
            vector.add(obj.getDiaChi());
            vector.add(obj.getQuyen());
            vector.add(obj.getTrangThai());
            defaultTableModel.addRow(vector);
        }
        jTable4.setModel(defaultTableModel);
    }

    public void layMaNVHD() {
        try {
            listNVHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select MaNV from ChiTietHoaDon";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien(rs.getString(1));
                listNVHD.add(nv);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        btlThem = new javax.swing.JButton();
        btlXoa = new javax.swing.JButton();
        btlSua = new javax.swing.JButton();
        btlThoat = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        txtTimkiem = new javax.swing.JTextField();
        btlTimKiem = new javax.swing.JButton();
        jlbXinChao = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtMaNV = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtTenNV = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        txtDiaChi = new javax.swing.JTextField();
        cbbGioiTinh = new javax.swing.JComboBox<>();
        cbbTrangThai = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cbbNhom = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        pwMatkhau = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setPreferredSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel6.setBackground(new java.awt.Color(204, 204, 255));

        jLabel14.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel15.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel6);
        jPanel6.setBounds(0, 850, 1920, 60);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1320, 636));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Tên nhân viên", "Email", "SDT", "Giới tính", "Địa chỉ", "Trạng thái", "Nhóm "
            }
        ));
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable4);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 1270, 220));

        btlThem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add_user_male_24px.png"))); // NOI18N
        btlThem.setText("Thêm");
        btlThem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThem.setPreferredSize(new java.awt.Dimension(100, 35));
        btlThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThemActionPerformed(evt);
            }
        });
        jPanel1.add(btlThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 210, 200, 50));

        btlXoa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_24px.png"))); // NOI18N
        btlXoa.setText("Xóa");
        btlXoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlXoa.setMaximumSize(new java.awt.Dimension(100, 35));
        btlXoa.setMinimumSize(new java.awt.Dimension(100, 35));
        btlXoa.setPreferredSize(new java.awt.Dimension(100, 35));
        btlXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlXoaActionPerformed(evt);
            }
        });
        jPanel1.add(btlXoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 210, 200, 50));

        btlSua.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pencil_drawing_24px.png"))); // NOI18N
        btlSua.setText("Sửa");
        btlSua.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlSua.setMaximumSize(new java.awt.Dimension(100, 35));
        btlSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlSuaActionPerformed(evt);
            }
        });
        jPanel1.add(btlSua, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 280, 200, 50));

        btlThoat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit_24px.png"))); // NOI18N
        btlThoat.setText("Reset");
        btlThoat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThoat.setPreferredSize(new java.awt.Dimension(100, 35));
        btlThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThoatActionPerformed(evt);
            }
        });
        jPanel1.add(btlThoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 280, 200, 50));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tìm kiếm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24), new java.awt.Color(255, 0, 0))); // NOI18N

        txtTimkiem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtTimkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimkiemActionPerformed(evt);
            }
        });

        btlTimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search_24px.png"))); // NOI18N
        btlTimKiem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btlTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btlTimKiem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtTimkiem, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 80, 550, 100));

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jlbXinChao.setForeground(new java.awt.Color(51, 0, 0));
        jPanel1.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 380, 50));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông tin nhân viên ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24), new java.awt.Color(255, 0, 0))); // NOI18N
        jPanel3.setToolTipText("Thông tin khách hàng");
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        txtMaNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtMaNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMaNVActionPerformed(evt);
            }
        });

        txtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        txtTenNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtTenNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTenNVActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Email");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Giới tính");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Trạng thái");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Tên nhân viên");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("SDT");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("Địa chỉ");

        txtSDT.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtSDT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSDTActionPerformed(evt);
            }
        });

        txtDiaChi.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtDiaChi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDiaChiActionPerformed(evt);
            }
        });

        cbbGioiTinh.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbGioiTinh.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nam", "Nữ" }));
        cbbGioiTinh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbGioiTinhActionPerformed(evt);
            }
        });

        cbbTrangThai.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hoạt động", "Không hoạt động" }));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("Mã nhân viên");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Nhóm NV");

        cbbNhom.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbNhom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quản lí", "Nhân viên" }));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("Mật khẩu");

        pwMatkhau.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel2)
                            .addComponent(jLabel13))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSDT)
                            .addComponent(cbbNhom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtDiaChi)
                            .addComponent(pwMatkhau))))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3))
                        .addGap(32, 32, 32))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbbGioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbbNhom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(cbbGioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(pwMatkhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel9.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText(" Lady’s house");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1320, 70));

        add(jPanel1);
        jPanel1.setBounds(300, 80, 1320, 636);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel1);
        jLabel1.setBounds(0, 0, 1930, 1020);
    }// </editor-fold>//GEN-END:initComponents

    private void txtTimkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimkiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimkiemActionPerformed

    private void txtMaNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMaNVActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_txtMaNVActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtTenNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTenNVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTenNVActionPerformed

    private void txtSDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSDTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSDTActionPerformed

    private void txtDiaChiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiaChiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDiaChiActionPerformed

    private void cbbGioiTinhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbGioiTinhActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbGioiTinhActionPerformed

    private void btlThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThemActionPerformed
        // TODO add your handling code here:
        if (txtMaNV.getText().trim().equals("") || txtTenNV.getText().trim().equals("") || txtEmail.getText().trim().equals("") || txtDiaChi.getText().trim().equals("") || txtSDT.getText().trim().equals("") || pwMatkhau.getText().trim().equals("")) {// điều kiện maKH rỗng
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        } else {
            if (kt() == false) {//kiểm tra độ dài của dữ liệu nhập vào

            } else {
                int dem = 0;
                int demEmail = 0;
                for (NhanVien nv : listNV) {
                    if (nv.getMaNV().trim().equals(txtMaNV.getText().trim())) {
                        dem = 1;
                    }
                    if (nv.getEmail().trim().equals(txtEmail.getText().trim())) {
                        demEmail = 1;
                    }
                }
                if (dem == 1) {
                    JOptionPane.showMessageDialog(this, "Mã nhân viên này đã tồn tại");
                } else {
                    if (ktemail.kt(txtEmail.getText().trim()) != true) {// điều kiện email
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập đúng định dạng email!");
                    } else {
                        if (demEmail == 1) {
                            JOptionPane.showMessageDialog(this, "Email này đã tồn tại");
                        } else {
                            if (ktso.ktc(txtSDT.getText().trim()) == false) {
                                JOptionPane.showMessageDialog(this, "SĐT không được chứa chữ!");
                            } else {
                                if (ktphone.testsdt(txtSDT.getText().trim()) == false) {
                                    JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng số 0");
                                } else {
                                    if (txtSDT.getText().trim().length() > 11 || txtSDT.getText().trim().length() < 10) {// điều kiện sdt
                                        JOptionPane.showMessageDialog(this, "SĐT phải chứa 10 hoặc 11 số!");
                                    } else {

                                        them(txtMaNV.getText().trim(), txtTenNV.getText().trim(), cbbGioiTinh.getSelectedItem().toString(), txtSDT.getText().trim(), txtEmail.getText().trim(), txtDiaChi.getText().trim(), cbbTrangThai.getSelectedItem().toString(), Bam.md5(pwMatkhau.getText().trim()), cbbNhom.getSelectedItem().toString());
                                        reset();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btlThemActionPerformed

    private void btlTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlTimKiemActionPerformed
        // TODO add your handling code here:
        //tìm kiếm theo tên KH,email, sdt
        listTK.clear();
        String caicantim = txtTimkiem.getText().trim();
        if (txtTimkiem.getText().equals("")) {//với textfile rỗng thì in ra cả ds
            getData(listNV);
        } else {// với textfild khác rỗng thì.
            timkiem(caicantim);
            if (listTK.size() == 0) {//khi không có KH trùng khớp thì thông báo
                JOptionPane.showMessageDialog(this, "Không có thông tin nhân viên nào liên quan!");
            } else {// in ra ds các KH liên quan
                getData(listTK);
            }
        }
    }//GEN-LAST:event_btlTimKiemActionPerformed

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        // TODO add your handling code here:
        int i = jTable4.getSelectedRow();
        NhanVien s = listNV.get(i);
        txtMaNV.setText(s.getMaNV().trim());
        txtTenNV.setText(s.getTenNV().trim());
        txtEmail.setText(s.getEmail().trim());
        txtSDT.setText(s.getSdt().trim());
        txtDiaChi.setText(s.getDiaChi().trim());
        pwMatkhau.setText(s.getMatKhau().trim());
        cbbGioiTinh.setSelectedItem(s.getGioiTinh().trim());
        cbbTrangThai.setSelectedItem(s.getTrangThai().trim());
        cbbNhom.setSelectedItem(s.getQuyen().trim());
        index = i;
        //Đóng băng ko cho sửa mã nv 
        txtMaNV.setEditable(false);
        pwMatkhau.setEditable(false);
    }//GEN-LAST:event_jTable4MouseClicked

    private void btlSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlSuaActionPerformed
        // TODO add your handling code here:
        if (txtTenNV.getText().trim().equals("") || txtEmail.getText().trim().equals("") || txtDiaChi.getText().trim().equals("") || txtSDT.getText().trim().equals("") || pwMatkhau.getText().trim().equals("")) {// điều kiện maKH rỗng
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        } else {
            if (kt() == false) {//kiểm tra độ dài của dữ liệu nhập vào

            } else {
                int demEmail = 0;
                for (int i = 0; i < listNV.size(); i++) {
                    if (listNV.get(i).getEmail().trim().equals(txtEmail.getText().trim())) {
                        demEmail = 1;
                        break;
                    }
                }
                if (demEmail == 1) {
                    if (!listNV.get(index).getEmail().trim().equals(txtEmail.getText().trim())) {
                        JOptionPane.showMessageDialog(this, "Email này đã được sử dụng!");
                    } else {
                        if (ktemail.kt(txtEmail.getText().trim()) != true) {// điều kiện email
                            JOptionPane.showMessageDialog(this, "Vui lòng nhập đúng định dạng email!");
                        } else {
                            if (ktphone.testsdt(txtSDT.getText().trim()) == false) {
                                JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng số 0");
                            } else {
                                if (txtSDT.getText().trim().length() > 11 || txtSDT.getText().trim().length() < 10) {// điều kiện sdt
                                    JOptionPane.showMessageDialog(this, "SĐT phải chứa 10 hoặc 11 số!");
                                } else {
                                    if (ktso.ktc(txtSDT.getText().trim()) == false) {
                                        JOptionPane.showMessageDialog(this, "SĐT không được chứa chữ!");
                                    } else {
                                        sua(txtMaNV.getText().trim(), txtTenNV.getText().trim(), cbbGioiTinh.getSelectedItem().toString(), txtSDT.getText().trim(), txtEmail.getText().trim(), txtDiaChi.getText().trim(), cbbTrangThai.getSelectedItem().toString(), cbbNhom.getSelectedItem().toString());
                                        reset();
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (ktemail.kt(txtEmail.getText().trim()) != true) {// điều kiện email
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập đúng định dạng email!");
                    } else {
                        if (ktphone.testsdt(txtSDT.getText().trim()) == false) {
                            JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng số 0");
                        } else {
                            if (txtSDT.getText().trim().length() > 11 || txtSDT.getText().trim().length() < 10) {// điều kiện sdt
                                JOptionPane.showMessageDialog(this, "SĐT phải chứa 10 hoặc 11 số!");
                            } else {
                                if (ktso.ktc(txtSDT.getText().trim()) == false) {
                                    JOptionPane.showMessageDialog(this, "SĐT không được chứa chữ!");
                                } else {
                                    sua(txtMaNV.getText().trim(), txtTenNV.getText().trim(), cbbGioiTinh.getSelectedItem().toString(), txtSDT.getText().trim(), txtEmail.getText().trim(), txtDiaChi.getText().trim(), cbbTrangThai.getSelectedItem().toString(), cbbNhom.getSelectedItem().toString());
                                    reset();
                                }
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btlSuaActionPerformed

    private void btlXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlXoaActionPerformed
        // TODO add your handling code here:
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn hàng để xóa!");
        } else {
            layMaNVHD();
            int dem = 0;
            for (NhanVien nv : listNVHD) {
                if (nv.getMaNV().trim().equals(listNV.get(index).getMaNV().trim())) {
                    dem = 1;
                    break;
                }
            }
            if (dem == 1) {
                JOptionPane.showMessageDialog(this, "Nhân viên này có ràng buộc với hóa đơn!");
                reset();
            } else {
                xoa(listNV.get(index).getMaNV());
                reset();
            }
        }
    }//GEN-LAST:event_btlXoaActionPerformed

    private void btlThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThoatActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btlThoatActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btlSua;
    private javax.swing.JButton btlThem;
    private javax.swing.JButton btlThoat;
    private javax.swing.JButton btlTimKiem;
    private javax.swing.JButton btlXoa;
    private javax.swing.JComboBox<String> cbbGioiTinh;
    private javax.swing.JComboBox<String> cbbNhom;
    private javax.swing.JComboBox<String> cbbTrangThai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable4;
    private javax.swing.JLabel jlbXinChao;
    private javax.swing.JPasswordField pwMatkhau;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTenNV;
    private javax.swing.JTextField txtTimkiem;
    // End of variables declaration//GEN-END:variables
}
