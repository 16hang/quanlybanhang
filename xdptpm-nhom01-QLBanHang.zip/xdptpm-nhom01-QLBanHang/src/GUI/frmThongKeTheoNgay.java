/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.CTHoaDon;
import OBJ.NhanVien;
import OBJ.SanPham;
import Utils.Conn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmThongKeTheoNgay extends javax.swing.JPanel {

    /**
     * Creates new form frmThongKeTheoNgay
     */
    NumberFormat formatTien = new DecimalFormat("###,###");
    //hóa đơn chi tiết  và hóa đơn lọc theo nv
    ArrayList<CTHoaDon> listCTHD = new ArrayList<>();
    private DefaultTableModel defaultTableModel;
    // ds sp vs sp lay từ HD
    ArrayList<SanPham> listSP = new ArrayList<>();
    ArrayList<SanPham> listSPHD = new ArrayList<>();
    ArrayList<NhanVien> listNV = new ArrayList<>();
    int index = -1;
    String maNV;

    public frmThongKeTheoNgay(String tenNV) {
        initComponents();
        jlbXinChao.setText("Xin chào, " + tenNV);
        loadCbb();
        loadListSP();
    }

    public void loadCbb() {
        cbbNV.removeAllItems();;
        cbbNV.addItem("Tất cả");
        listNV.clear();
        loadListNV();
        for (NhanVien a : listNV) {
            cbbNV.addItem(a.getMaNV());
        }
    }

    //Lấy đối tượng bảng nhân viên để lấy ds nhân viên
    frmNhanVien frmNV = new frmNhanVien();

    public void loadListNV() {
        listNV.clear();
        listNV = frmNV.loadFile();
    }

    //Lấy đối tượng bảng sản phẩm để lấy ds sản phẩm
    frmSanPham frmSP = new frmSanPham();

    public void loadListSP() {
        listSP.clear();
        listSP = frmSP.loadFile();
    }

    //Lấy ds hóa đơn theo ngày
    public void layDSHD(String caicantim) {
        try {
            listCTHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from ChiTietHoaDon where NgayBan like '" + caicantim + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                CTHoaDon hd = new CTHoaDon(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(5));
                listCTHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Lấy ds hóa đơn theo ngày và nhân viên
    public void layDSHDNV(String ngay, String manv) {
        try {
            listCTHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from ChiTietHoaDon where NgayBan like '" + ngay + "%' and MaNV = '" + manv + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                CTHoaDon hd = new CTHoaDon(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(5));
                listCTHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Lấy ds các sản phẩm của 1 hóa đơn
    public void layDSSP(String caicantim) {
        try {
            listSPHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from HoaDon where MaHD = '" + caicantim.trim() + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham hd = new SanPham(rs.getString(4), rs.getInt(5), rs.getInt(6));
                listSPHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Hiển thị ds hóa đơn bán được trong 1 ngày
    private void getListHD(ArrayList<CTHoaDon> listCTHD) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã DH");
        defaultTableModel.addColumn("Mã NV");
        defaultTableModel.addColumn("Ngáy bán");
        defaultTableModel.addColumn("Tổng tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp

        for (CTHoaDon hd : listCTHD) {
            Vector vector = new Vector();
            vector.add(hd.getMaHD());
            vector.add(hd.getMaNV());
            vector.add(hd.getNgayBan());
            vector.add(formatTien.format(hd.getTong()));

            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }

        //thêm các thuộc tính đã lưu vào bảng
        jTable1.setModel(defaultTableModel);

    }

    //Hiển thị các sản phẩm chi tiết trong 1 hóa đơn
    private void getThongTin(ArrayList<SanPham> listSPHD) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Mã NCC");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá bán");
        defaultTableModel.addColumn("Tổng tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp
        for (SanPham sp : listSPHD) {
            Vector vector = new Vector();
            vector.add(sp.getMaSP());
            vector.add(layTenSP(sp.getMaSP()));
            vector.add(layMaNCC(sp.getMaSP()));
            vector.add(sp.getSoLuong());
            vector.add(formatTien.format(sp.getGiaBan()));
            vector.add(formatTien.format(sp.getSoLuong() * sp.getGiaBan()));
            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable2.setModel(defaultTableModel);

    }

    public String layTenSP(String maSP) {
        String ten = "";
        listSP.clear();
        loadListSP();
        for (SanPham sp : listSP) {
            if (maSP.trim().equals(sp.getMaSP().trim())) {
                ten = sp.getTenSP();
                break;
            }
        }
        return ten;
    }

    public String layMaNCC(String maSP) {
        String mancc = "";
        listSP.clear();
        loadListSP();
        for (SanPham sp : listSP) {
            if (maSP.trim().equals(sp.getMaSP().trim())) {
                mancc = sp.getMaNCC();
                break;
            }
        }
        return mancc;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jlbXinChao = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jDate = new com.toedter.calendar.JDateChooser();
        btnThongKe = new javax.swing.JButton();
        cbbNV = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jlbTongTien = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel8.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel11.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 232, 23));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setDragEnabled(true);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("(vnđ)");

        jDate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        btnThongKe.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnThongKe.setText("Thống kê");
        btnThongKe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeActionPerformed(evt);
            }
        });

        cbbNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbNV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Ngày tháng năm");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setEnabled(false);
        jScrollPane2.setViewportView(jTable2);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Nhân viên");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Tổng tiền:");

        jlbTongTien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlbTongTien.setText("...");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 204));
        jLabel6.setText("Danh sách hóa đơn");

        jLabel7.setBackground(new java.awt.Color(0, 0, 204));
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 204));
        jLabel7.setText("Chi tiết hóa đơn");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(440, 440, 440)
                .addComponent(jLabel6))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(19, 19, 19)
                        .addComponent(jDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(btnThongKe))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(31, 31, 31)
                        .addComponent(cbbNV, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(38, 38, 38)
                        .addComponent(jlbTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jLabel7))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThongKe)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(cbbNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel4))
                            .addComponent(jlbTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(jLabel7)
                .addGap(11, 11, 11)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 51, 1000, 490));

        jLabel9.setBackground(new java.awt.Color(204, 204, 255));
        jLabel9.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText(" Lady’s house");
        jLabel9.setOpaque(true);
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 60));

        add(jPanel1);
        jPanel1.setBounds(460, 160, 994, 538);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel5);
        jLabel5.setBounds(0, 0, 1920, 980);
    }// </editor-fold>//GEN-END:initComponents

    private void btnThongKeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeActionPerformed
        // TODO add your handling code here:
        Date date = jDate.getDate();
        String dateString = String.format("%1$td-%1$tm-%1$tY", date);
        if (cbbNV.getSelectedItem().toString().trim().equals("Tất cả")) {
            layDSHD(dateString);
            getListHD(listCTHD);
            int tt = 0;
            for (CTHoaDon ct : listCTHD) {
                tt += ct.getTong();
            }
            jlbTongTien.setText(String.valueOf(formatTien.format(tt)));
        } else {
            layDSHDNV(dateString, cbbNV.getSelectedItem().toString().trim());
            getListHD(listCTHD);
            int tt = 0;
            for (CTHoaDon ct : listCTHD) {
                tt += ct.getTong();
            }
            jlbTongTien.setText(String.valueOf(formatTien.format(tt)));
        }
        listSPHD.clear();
        getThongTin(listSPHD);
    }//GEN-LAST:event_btnThongKeActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int i = jTable1.getSelectedRow();
        String tkim = listCTHD.get(i).getMaHD();
        layDSSP(tkim);
        getThongTin(listSPHD);
    }//GEN-LAST:event_jTable1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnThongKe;
    private javax.swing.JComboBox<String> cbbNV;
    private com.toedter.calendar.JDateChooser jDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel jlbTongTien;
    private javax.swing.JLabel jlbXinChao;
    // End of variables declaration//GEN-END:variables
}
