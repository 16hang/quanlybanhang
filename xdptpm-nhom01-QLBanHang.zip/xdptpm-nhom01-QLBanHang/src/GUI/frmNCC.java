/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NCC;
import OBJ.SanPham;
import Utils.Conn;
import Utils.KTSdt;
import Utils.KTSo;
import Utils.KichThuocData;
import Utils.KtEmail;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmNCC extends javax.swing.JPanel {

    /**
     * Creates new form frmNCC
     */
    KTSo ktchu = new KTSo();
    KTSdt ktphone = new KTSdt();
    KtEmail ktemail = new KtEmail();
    KichThuocData ktmax = new KichThuocData();
    private DefaultTableModel defaultTableModel;
    //tạo danh sách nhà cung cấp và danh sách tìm kiếm
    ArrayList<NCC> listNCC = new ArrayList<>();
    ArrayList<NCC> listTK = new ArrayList<>();
    int index = -1;

    public frmNCC(String tenNV) {
        initComponents();
        jlbXinChao.setText("Xin chào, " + tenNV);
        loadFile();
        getData(listNCC);
        System.out.println(listNCC.size());
    }

    public frmNCC() {
        initComponents();
    }

    public void reset() {
        //Trả về trạng thái bình thường cho các ô nhập
        txtTimKiem.setText("");
        txtMaNCC.setText("");
        txtMaNCC.enable();
        txtTenNCC.setText("");
        txtDiaChi.setText("");
        txtEmail.setText("");
        txtSDT.setText("");
        //Làm rỗng lại danh sách rồi load lại từ đầu
        listNCC.clear();
        loadFile();
        getData(listNCC);
    }

    //Hàm so sánh kích thước nhập vào vói csdl
    public boolean kt() {
        boolean kq = true;
        if (txtMaNCC.getText().length() > ktmax.layKichThuoc("ncc", "mancc")) {
            JOptionPane.showMessageDialog(this, "Mã nhà cung cấp không được nhập quá " + ktmax.layKichThuoc("ncc", "mancc") + " kí tự!");
            kq = false;
        } else {
            if (txtDiaChi.getText().length() > ktmax.layKichThuoc("ncc", "diachi")) {
                JOptionPane.showMessageDialog(this, "Địa chỉ không được nhập quá " + ktmax.layKichThuoc("ncc", "diachi") + " kí tự!");
                kq = false;
            } else {
                if (txtEmail.getText().length() > ktmax.layKichThuoc("ncc", "email")) {
                    JOptionPane.showMessageDialog(this, "Email không được nhập quá " + ktmax.layKichThuoc("ncc", "email") + " kí tự!");
                    kq = false;
                } else {
                    if (txtSDT.getText().length() > ktmax.layKichThuoc("ncc", "sdt")) {
                        JOptionPane.showMessageDialog(this, "Số điện thoại không được nhập quá " + ktmax.layKichThuoc("ncc", "sdt") + " kí tự!");
                        kq = false;
                    } else {
                        if (txtTenNCC.getText().length() > ktmax.layKichThuoc("ncc", "tenncc")) {
                            JOptionPane.showMessageDialog(this, "Mã nhà cung cấp không được nhập quá " + ktmax.layKichThuoc("ncc", "tenncc") + " kí tự!");
                            kq = false;
                        } else {
                            kq = true;
                        }
                    }
                }
            }
        }
        return kq;
    }

    //Hàm load ncc ra ds(hàm chọn ko điều kiện)
    public ArrayList<NCC> loadFile() {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from NCC";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NCC nsx = new NCC(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                listNCC.add(nsx);
            }
            conn.close();
            return listNCC;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            return null;
        }

    }

    //Hàm hiển thị danh sách ncc ra bảng
    private void getData(ArrayList<NCC> listNCC) {
        defaultTableModel = new DefaultTableModel();
        defaultTableModel.addColumn("Mã NCC");
        defaultTableModel.addColumn("Tên NCC");
        defaultTableModel.addColumn("Email");
        defaultTableModel.addColumn("SĐT");
        defaultTableModel.addColumn("Địa chỉ");

        for (NCC obj : listNCC) {
            Vector vector = new Vector();
            vector.add(obj.getMaNCC());
            vector.add(obj.getTenNCC());
            vector.add(obj.getEmail());
            vector.add(obj.getSdt());
            vector.add(obj.getDiaChi());
            defaultTableModel.addRow(vector);
        }
        jtbNSX.setModel(defaultTableModel);
    }
    //Hàm thêm 1 ncc vào csdl

    public void them(String maNSX, String tenNSX, String email, String sdt, String diaChi) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            String query = "INSERT into NCC values('" + maNSX + "',N'" + tenNSX + "', '" + email + "', '" + sdt + "', N'" + diaChi + "')";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            ps.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(this, "Thêm thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
        }
    }

    //Hàm sửa 1 ncc vào csdl
    public void sua(String maNSX, String tenNSX, String email, String sdt, String diaChi) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            String query = "Update NCC SET TenNCC=N'" + tenNSX + "', Email= '" + email + "', SDT= '" + sdt + "', DiaChi= N'" + diaChi + "' where MaNCC = '" + maNSX + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            ps.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(this, "Sửa thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sửa không thành công!");
            e.printStackTrace();
        }
    }

    //Hàm xóa 1 ncc vào csdl
    public void xoa(String maNSX) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs; // kết quả
            String query = "Delete from NCC where maNCC = '" + maNSX + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(this, "Xóa thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Không xóa được do ràng buộc sản phẩm!");
        }
    }

    //Hàm tìm kiếm 1 ncc vào csdl(thực ra là chọn có điều kiện)
    public void timkiem(String tenNSX) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from NCC where TenNCC like N'%" + tenNSX + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NCC nsx = new NCC(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                listTK.add(nsx);
            }
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tìm kiếm");

        }

    }

    public int demSPCuaNCC(String maNCC) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select count(*) from SanPham where MaNCC like '%" + maNCC + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tìm kiếm");
        }
        return 0;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnTimKiem = new javax.swing.JButton();
        jlbXinChao = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        txtSDT = new javax.swing.JTextField();
        txtDiaChi = new javax.swing.JTextField();
        txtMaNCC = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnSua = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtbNSX = new javax.swing.JTable();
        txtEmail = new javax.swing.JTextField();
        txtTenNCC = new javax.swing.JTextField();
        btlThoat = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 204, 255));
        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setPreferredSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel6.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel9.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Mã NCC");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 83, -1, -1));

        btnThem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add1.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnThem.setPreferredSize(new java.awt.Dimension(120, 50));
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });
        jPanel3.add(btnThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, -1, -1));

        btnXoa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete_24px.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });
        jPanel3.add(btnXoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 350, 120, 50));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Email");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 178, -1, -1));

        btnTimKiem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnTimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search_24px.png"))); // NOI18N
        btnTimKiem.setText("Tìm kiếm");
        btnTimKiem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });
        jPanel3.add(btnTimKiem, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 70, 140, 40));

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        jlbXinChao.setForeground(new java.awt.Color(51, 0, 0));
        jPanel3.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 370, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("SDT");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 224, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Địa chỉ");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 270, -1, -1));

        txtTimKiem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtTimKiem, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 68, 266, 40));

        txtSDT.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtSDT, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 221, 266, -1));

        txtDiaChi.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtDiaChi, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 267, 266, -1));

        txtMaNCC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtMaNCC, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 266, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Tên NCC");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 130, -1, -1));

        btnSua.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pencil_drawing_24px.png"))); // NOI18N
        btnSua.setText("Sửa");
        btnSua.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSua.setMaximumSize(new java.awt.Dimension(131, 41));
        btnSua.setMinimumSize(new java.awt.Dimension(131, 41));
        btnSua.setPreferredSize(new java.awt.Dimension(120, 50));
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });
        jPanel3.add(btnSua, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 350, 110, -1));

        jtbNSX.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jtbNSX.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jtbNSX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbNSXMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtbNSX);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 140, 570, 170));

        txtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 175, 266, -1));

        txtTenNCC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtTenNCC, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 127, 266, -1));

        btlThoat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit_24px.png"))); // NOI18N
        btlThoat.setText("Reset");
        btlThoat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThoat.setPreferredSize(new java.awt.Dimension(100, 35));
        btlThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThoatActionPerformed(evt);
            }
        });
        jPanel3.add(btlThoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 350, 110, 50));

        jLabel8.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText(" Lady’s house");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 60));

        add(jPanel3);
        jPanel3.setBounds(430, 160, 1050, 425);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel7);
        jLabel7.setBounds(0, 0, 1940, 1010);
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        if (txtMaNCC.getText().trim().equals("") || txtTenNCC.getText().trim().equals("") || txtDiaChi.getText().trim().equals("") || txtEmail.getText().trim().equals("") || txtSDT.getText().trim().equals("")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        } else {
            if (kt() == false) {

            } else {
                int kt = 0;
                listNCC.clear();
                loadFile();
                for (NCC nsx : listNCC) {
                    if (txtMaNCC.getText().trim().equals(nsx.getMaNCC().trim())) {
                        kt = 1;
                        break;
                    }
                }
                if (kt == 1) {
                    JOptionPane.showMessageDialog(this, "Mã NCC này đã được sử dụng!");
                } else {
                    if (ktemail.kt(txtEmail.getText()) != true) {// điều kiện email
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập email đúng định dạng!");
                    } else {
                        if (ktphone.testsdt(txtSDT.getText().trim()) == false) {
                            JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng số 0!");
                        } else {
                            if (txtSDT.getText().trim().length() > 11 || txtSDT.getText().trim().length() < 10) {// điều kiện sdt
                                JOptionPane.showMessageDialog(this, "SĐT phải chứ 10 hoặc 11 số!");
                            } else {
                                if (ktchu.ktc(txtSDT.getText().trim()) == false) {
                                    JOptionPane.showMessageDialog(this, "SĐT không được chứa chữ!");
                                } else {
                                    them(txtMaNCC.getText().trim(), txtTenNCC.getText().trim(), txtEmail.getText().trim(), txtSDT.getText().trim(), txtDiaChi.getText().trim());
                                    reset();
                                }
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        if (txtTenNCC.getText().trim().equals("")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        } else {
            if (kt() == false) {

            } else {
                if (ktemail.kt(txtEmail.getText()) != true) {// điều kiện email
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập email đúng định dạng!");
                } else {
                    if (ktphone.testsdt(txtSDT.getText().trim()) == false) {
                        JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng số 0!");
                    } else {
                        if (txtSDT.getText().trim().length() > 11 || txtSDT.getText().trim().length() < 10) {// điều kiện sdt
                            JOptionPane.showMessageDialog(this, "SĐT phải chứ 10 hoặc 11 số!");
                        } else {
                            if (ktchu.ktc(txtSDT.getText().trim()) == false) {
                                JOptionPane.showMessageDialog(this, "SĐT không được chứa chữ!");
                            } else {
                                sua(txtMaNCC.getText().trim(), txtTenNCC.getText().trim(), txtEmail.getText().trim(), txtSDT.getText().trim(), txtDiaChi.getText().trim());
                                reset();
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn hàng để xóa!");
        } else {
            int a = demSPCuaNCC(listNCC.get(index).getMaNCC().trim());
            if (a != 0) {
                JOptionPane.showMessageDialog(this, "Không xóa được thông tin nhà cung cấp do có ràng buộc với sản phẩm!");
            } else {
                xoa(txtMaNCC.getText().trim());
                reset();
            }

        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btlThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThoatActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btlThoatActionPerformed

    private void jtbNSXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbNSXMouseClicked
        // TODO add your handling code here:
        index = jtbNSX.getSelectedRow();
        txtMaNCC.setText(listNCC.get(index).getMaNCC().trim());
        txtTenNCC.setText(listNCC.get(index).getTenNCC().trim());
        txtDiaChi.setText(listNCC.get(index).getDiaChi().trim());
        txtEmail.setText(listNCC.get(index).getEmail().trim());
        txtSDT.setText(listNCC.get(index).getSdt().trim());
        txtMaNCC.disable();
    }//GEN-LAST:event_jtbNSXMouseClicked

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        // TODO add your handling code here:
        timkiem(txtTimKiem.getText().trim());
        if (listTK.size() == 0) {
            JOptionPane.showMessageDialog(this, "Không có kết quả phù hợp!");
        } else {
            getData(listTK);
            listTK.clear();
            txtTimKiem.setText("");
        }
    }//GEN-LAST:event_btnTimKiemActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btlThoat;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jlbXinChao;
    private javax.swing.JTable jtbNSX;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtMaNCC;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTenNCC;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
