/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NCC;
import OBJ.SanPham;
import Utils.Conn;
import Utils.KTSo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmBanHang extends javax.swing.JPanel {

    /**
     * Creates new form frmBanHang
     */
    int index = -1, indexGH = -1, tongT = 0;
    String maNV;
    NumberFormat formatTien = new DecimalFormat("###,###");
    // kiểm tra số lượng ko chứa chữ
    KTSo ktC = new KTSo();

    private DefaultTableModel defaultTableModel;
    ArrayList<SanPham> listSP = new ArrayList<>();
    ArrayList<SanPham> listTK = new ArrayList<>();//ds tìm kiếm sp
    ArrayList<NCC> listNCC = new ArrayList<>();//ds ncc
    ArrayList<SanPham> listGH = new ArrayList<>();//ds giỏ hàng

    public frmBanHang() {
        initComponents();
    }

    public frmBanHang(String ma, String tenNV) {
        initComponents();
        loadListSP();
        loadListNCC();
        getDataSP(listSP);
        getDataBan(listGH);
        jbXinChao.setText("Xin chào, " + tenNV);
        maNV = ma;

    }
    //Gọi đối tưởng bảng Sản phẩm để lấy ds sp
    frmSanPham fSP = new frmSanPham();

    public void loadListSP() {
        listSP.clear();
        listSP = fSP.loadFile();
    }

    public void timKiemSP(String caicantim) {
        try {
            listTK.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from SanPham where TenSP like N'%" + caicantim + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7));
                listTK.add(sp);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ko kết nối dc");
            e.printStackTrace();
        }
    }

    //Tạo đối tượng frmNCC để lấy ds NCC 
    frmNCC fNCC = new frmNCC();

    public void loadListNCC() {
        listNCC.clear();
        listNCC = fNCC.loadFile();
    }

    public String layTenNCC(String maNCC) {
        String ten = "";
        for (NCC ncc : listNCC) {
            if (ncc.getMaNCC().trim().equals(maNCC)) {
                ten = ncc.getTenNCC().trim();
                break;
            }
        }
        return ten;
    }

    //Do mã hóa đơn tăng dần nên mã HD mới = số hóa đơn đã có +1
    public int demSoHoaDon() {
        try {
            int dem = 0;
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select count(*) from ChiTietHoaDon ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                dem = Integer.parseInt(rs.getString(1));
            }
            conn.close();
            return dem;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối");
            e.printStackTrace();
            return -1;
        }
    }

    //Load ds sp lên bảng sp
    private void getDataSP(ArrayList<SanPham> listSP) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Tên NCC");
        defaultTableModel.addColumn("Đơn vị tính");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá bán");

        //thêm dữ liệu của từng cột của bảng từ listSP
        for (SanPham obj : listSP) {
            Vector vector = new Vector();
            vector.add(obj.getMaSP());
            vector.add(obj.getTenSP());
            vector.add(layTenNCC(obj.getMaNCC()));//lay ten ncc
            vector.add(obj.getDonVT());
            vector.add(formatTien.format(obj.getSoLuong()));
            vector.add(formatTien.format(obj.getGiaBan()));

            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable2.setModel(defaultTableModel);

    }

    // in ra bảng giỏ hàng
    private void getDataBan(ArrayList<SanPham> listGH) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Tên NCC");
        defaultTableModel.addColumn("Đơn vị tính");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá bán");
        defaultTableModel.addColumn("Thành tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp
        for (SanPham obj : listGH) {

            Vector vector = new Vector();
            vector.add(obj.getMaSP());
            vector.add(obj.getTenSP());
            vector.add(layTenNCC(obj.getMaNCC()));
            vector.add(obj.getDonVT());
            vector.add(formatTien.format(obj.getSoLuong()));
            vector.add(formatTien.format(obj.getGiaBan()));
            vector.add(formatTien.format(obj.getSoLuong() * obj.getGiaBan()));

            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable4.setModel(defaultTableModel);

    }

    public void luuHD(String maHD, String maNV, String thoigian, String maSP, int soLuong, int giaBan) {
        try {
            Connection conn = new Conn().getConnection();
            String query = "Insert into HoaDon   values('" + maHD.trim() + "', '" + maNV.trim() + "', '" + thoigian.trim() + "', '" + maSP.trim() + "', " + soLuong + ", " + giaBan + ", " + soLuong * giaBan + ")  ";
            PreparedStatement sp = conn.prepareStatement(query);
            int rs = sp.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi lưu hóa đơn.");
            e.printStackTrace();
        }
    }

    public void luuChiTietHD(String maHD, String maNV, String thoigian, String thongTin, int tongTien) {
        try {
            Connection conn = new Conn().getConnection();
            String query = "Insert into ChiTietHoaDon values('" + maHD.trim() + "', '" + maNV.trim() + "', '" + thoigian.trim() + "', '" + thongTin + "', " + tongTien + ")   ";
            PreparedStatement sp = conn.prepareStatement(query);
            int rs = sp.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi lưu chi tiết hóa đơn.");
            e.printStackTrace();
        }
    }

    //Cập nhật số lượng
    public void capnhat(String maSP, int soLuong) {
        try {
            Connection conn = new Conn().getConnection();
            String query = "Update SanPham SET SoLuong = '" + soLuong + "' where MaSP= '" + maSP + "' ";
            PreparedStatement sp = conn.prepareStatement(query);
            int rs = sp.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật.");
            e.printStackTrace();
        }
    }

    public int laySLTrongKho(String maSP) {
        int soluong = 0;
        for (SanPham sp : listSP) {
            if (sp.getMaSP().trim().equals(maSP.trim())) {
                soluong = sp.getSoLuong();
                break;
            }
        }
        return soluong;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jbXinChao = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        txtTimkiemSP = new javax.swing.JTextField();
        btnTKSP = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtSL = new javax.swing.JTextField();
        txtTHemVGH = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        lbTongtien = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnXoa = new javax.swing.JButton();
        btlThanhToan = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setPreferredSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbXinChao.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        jbXinChao.setForeground(new java.awt.Color(51, 0, 51));
        jPanel1.add(jbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 460, 50));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Sản phẩm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 18), new java.awt.Color(204, 0, 0))); // NOI18N

        jTable2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setRowHeight(18);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        txtTimkiemSP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        btnTKSP.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnTKSP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/search_24px.png"))); // NOI18N
        btnTKSP.setText("Tìm kiếm");
        btnTKSP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTKSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTKSPActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("Số lượng:");

        txtSL.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        txtTHemVGH.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtTHemVGH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add1.png"))); // NOI18N
        txtTHemVGH.setText("Thêm vào giỏ hàng");
        txtTHemVGH.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtTHemVGH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTHemVGHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(txtTimkiemSP, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(btnTKSP)
                .addContainerGap(147, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(txtSL, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(txtTHemVGH, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimkiemSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTKSP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtSL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTHemVGH))
                .addGap(22, 22, 22))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 670, 330));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Thông tin hóa đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 18), new java.awt.Color(204, 0, 0))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Giỏ hàng:");

        jTable4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable4.setRowHeight(18);
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Tổng tiền:");

        lbTongtien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbTongtien.setText("....");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("(VND)");

        btnXoa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete_24px.png"))); // NOI18N
        btnXoa.setText("Xóa khỏi giỏ hàng");
        btnXoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbTongtien, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(lbTongtien)
                            .addComponent(jLabel4))
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 90, 640, 330));

        btlThanhToan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThanhToan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/tick.png"))); // NOI18N
        btlThanhToan.setText("Thanh toán");
        btlThanhToan.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThanhToanActionPerformed(evt);
            }
        });
        jPanel1.add(btlThanhToan, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 460, -1, 40));

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit_24px.png"))); // NOI18N
        jButton3.setText("Thoát");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 460, 110, 40));

        jLabel1.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" Lady’s house");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        add(jPanel1);
        jPanel1.setBounds(270, 160, 1399, 538);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel6.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel7.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jLabel2.setFont(new java.awt.Font("Vivaldi", 0, 36)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        jLabel2.setText("Chúng tôi ở đây để phục vụ bạn-  siêu thị Lady’s house");
        add(jLabel2);
        jLabel2.setBounds(0, 0, 1920, 970);
    }// </editor-fold>//GEN-END:initComponents

    private void txtTHemVGHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTHemVGHActionPerformed
        // TODO add your handling code here:
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn sản phẩm cần bán!");
        } else {
            if (txtSL.getText().trim().equals("")) {
                JOptionPane.showMessageDialog(this, "Nhập số lượng trước khi thêm vào giỏ hàng!");
            } else {
                if (ktC.ktc(txtSL.getText().trim()) == false) {
                    JOptionPane.showMessageDialog(this, "Số lượng không được nhập chữ!");
                } else {
                    if (Integer.parseInt(txtSL.getText().trim()) <= 0) {
                        JOptionPane.showMessageDialog(this, "Số lượng lớn hơn 0!");
                    } else {
                        int kiemtra = 0;
                        int vitri = 0;
                        SanPham sp = listSP.get(index);
                        for (int i = 0; i < listGH.size(); i++) {
                            if (listGH.get(i).getMaSP() == sp.getMaSP()) {
                                kiemtra = 1;
                                vitri = i;
                                break;
                            }
                        }
                        if (kiemtra == 0) {
                            if (sp.getSoLuong() == 0) {
                                JOptionPane.showMessageDialog(this, "Mặt hàng này đang hết!");
                            } else {
                                if (sp.getSoLuong() < Integer.parseInt(txtSL.getText().trim())) {
                                    JOptionPane.showMessageDialog(this, "Không đủ hàng để bán!");
                                } else {
                                    SanPham s = new SanPham();
                                    s.setTenSP(listSP.get(index).getTenSP());
                                    s.setMaSP(listSP.get(index).getMaSP());
                                    s.setMaNCC(listSP.get(index).getMaNCC());
                                    s.setDonVT(listSP.get(index).getDonVT());
                                    s.setSoLuong(Integer.parseInt(txtSL.getText().trim()));
                                    s.setGiaBan(listSP.get(index).getGiaBan());
                                    listGH.add(s);
                                    getDataBan(listGH);
                                }
                            }
                        } else {
                            //Lấy số lượng trong giỏ hàng + số lượng thêm vào
                            int soL = listGH.get(vitri).getSoLuong() + Integer.parseInt(txtSL.getText().trim());

                            if (listSP.get(index).getSoLuong() < listGH.get(vitri).getSoLuong() + Integer.parseInt(txtSL.getText().trim())) {
                                JOptionPane.showMessageDialog(this, "Không đủ hàng để bán!");
                            } else {
                                SanPham s = new SanPham();
                                s.setTenSP(listSP.get(index).getTenSP());
                                s.setMaSP(listSP.get(index).getMaSP());
                                s.setMaNCC(listSP.get(index).getMaNCC());
                                s.setDonVT(listSP.get(index).getDonVT());
                                s.setSoLuong(soL);
                                s.setGiaBan(listSP.get(index).getGiaBan());
                                listGH.set(vitri, s);
                                getDataBan(listGH);

                            }
                        }
                    }
                }
            }
        }
        int tongtien = 0;
        for (SanPham gh : listGH) {
            tongtien = tongtien + gh.getSoLuong() * gh.getGiaBan();
        }

        tongT = tongtien;
        lbTongtien.setText(String.valueOf(formatTien.format(tongtien)));
        txtSL.setText("");
        getDataBan(listGH);
        tongtien = 0;
    }//GEN-LAST:event_txtTHemVGHActionPerformed

    private void btnTKSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTKSPActionPerformed
        // TODO add your handling code here:
        String a = txtTimkiemSP.getText().trim();
        ArrayList<SanPham> sptk = new ArrayList<>();

        if (a.equals("")) {
            //hien thi toan bo sp
            loadListSP();
            getDataSP(listSP);
        } else {
            listTK.clear();
            timKiemSP(a);
            if (listTK.size() == 0) {
                JOptionPane.showMessageDialog(this, "Không có sản phẩm liên quan đến " + a);
            } else {
                getDataSP(listTK);
            }
        }
    }//GEN-LAST:event_btnTKSPActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        if (indexGH < 0) {
            JOptionPane.showMessageDialog(this, "Không có gì để xóa");
        } else {
            // xóa hàng
            listGH.remove(indexGH);
            //in lại bảng giỏ hàng sau xóa
            getDataBan(listGH);
            int tien = 0;
            for (SanPham x : listGH) {
                tien = tien + x.getGiaBan() * x.getSoLuong();
            }
            // in lại hàng tổng tiền
            lbTongtien.setText(String.valueOf(tien));
            indexGH = -1;
            tongT = tien;
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btlThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThanhToanActionPerformed
        // TODO add your handling code here:
        String thongTin = "";
        if (maNV == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng đăng nhập");
        } else {
            //tạo 1 thông báo có nút OK vào ô nhập tiền
            if (listGH.size() == 0) {
                JOptionPane.showMessageDialog(this, "Giỏ hàng rỗng!");
            } else {
                JTextField txtSoTien1 = new JTextField(20);
                //Tạo ô nhập tiền
                JPanel myPanel = new JPanel();
                myPanel.add(Box.createHorizontalStrut(10));
                myPanel.add(new JLabel("Số tiền khách đưa"));
                myPanel.add(txtSoTien1);

                int result = JOptionPane.showConfirmDialog(this, myPanel, "Số tiền khách thanh toán ", JOptionPane.OK_OPTION);
                // sau khi ấn nút OK
                if (txtSoTien1.getText().trim().equals("")) {
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập giá tiền");
                } else {
                    if (txtSoTien1.getText().length() > 10) {
                        JOptionPane.showMessageDialog(this, "Số tiền không được nhập quá 10 chữ số!");
                    } else {
                        if (ktC.ktc(txtSoTien1.getText()) == false) {
                            JOptionPane.showMessageDialog(this, "Ô này không được nhập chữ");
                        } else {
                            int soTienKhachDua = Integer.parseInt(txtSoTien1.getText().trim());
                            if (result == JOptionPane.OK_OPTION) {
                                // số tiền khách trả ko đủ
                                if (soTienKhachDua < tongT) {
                                    JOptionPane.showMessageDialog(this, "Số tiền khách đưa không đủ");
                                } else {// Khách trả đủ
                                    //Hiển thị số tiền trả lại
                                    JOptionPane.showMessageDialog(this, "NV trả lại: " + (soTienKhachDua - tongT));
                                    JOptionPane.showMessageDialog(this, "Thanh toán thành công");
                                    //mã hóa đơn = số hóa đơn +1
                                    String maHD = String.valueOf(demSoHoaDon() + 1);
                                    if (maHD.length() < 5) {//1>00001
                                        String m = "";
                                        for (int i = 0; i < 5 - maHD.length(); i++) {
                                            m += "0";
                                        }
                                        maHD = m + maHD;
                                    }
                                    //hàm thời gian , định dạng thời gian
                                    Date date = new Date();
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
                                    String thoigian = sdf.format(date);
                                    for (SanPham sp : listGH) {
                                        // thông tin hóa đơn 
                                        thongTin += sp.getTenSP() + "\t" + layTenNCC(sp.getMaNCC()) + "\t" + sp.getSoLuong() + "\t" + sp.getGiaBan() + "\t" + sp.getSoLuong() * sp.getGiaBan();
                                    }
                                    // lưu lại hóa đơn
                                    luuChiTietHD(maHD, maNV, thoigian, thongTin, tongT);
                                    for (SanPham sp : listGH) {
                                        luuHD(maHD, maNV, thoigian, sp.getMaSP(), sp.getSoLuong(), sp.getGiaBan());
                                        int sLuongMoi = laySLTrongKho(sp.getMaSP()) - sp.getSoLuong();
                                        capnhat(sp.getMaSP(), sLuongMoi);
                                    }
                                    // load lại thông tin cho ds SP
                                    listSP.clear();
                                    loadListSP();
                                    getDataSP(listSP);
                                    listGH.clear();
                                    getDataBan(listGH);
                                    lbTongtien.setText("...");
                                }
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btlThanhToanActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i = jTable2.getSelectedRow();
        index = i;
        txtSL.setText("1");
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        // TODO add your handling code here:
        int i = jTable4.getSelectedRow();
        indexGH = i;
    }//GEN-LAST:event_jTable4MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btlThanhToan;
    private javax.swing.JButton btnTKSP;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JLabel jbXinChao;
    private javax.swing.JLabel lbTongtien;
    private javax.swing.JTextField txtSL;
    private javax.swing.JButton txtTHemVGH;
    private javax.swing.JTextField txtTimkiemSP;
    // End of variables declaration//GEN-END:variables
}
