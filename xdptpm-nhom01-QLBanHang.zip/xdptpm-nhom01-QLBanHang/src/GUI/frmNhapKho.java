/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NCC;
import OBJ.SanPham;
import Utils.Conn;
import Utils.KTSo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmNhapKho extends javax.swing.JPanel {

    /**
     * Creates new form frmNhapKho
     */
    KTSo kt = new KTSo();
    int tongtien = 0, index = -1;

    NumberFormat formatTien = new DecimalFormat("###,###");

    private DefaultTableModel defaultTableModel;

    frmNCC frmNCC = new frmNCC();
    frmSanPham frmSP = new frmSanPham();

    ArrayList<NCC> listNCC = new ArrayList<>();
    ArrayList<SanPham> listSP = new ArrayList<>();//Ds sp theo ncc
    ArrayList<SanPham> listSPFull = new ArrayList<>();//Ds sp 
    ArrayList<SanPham> listNK = new ArrayList<>();//Ds nhập kho
    String maCbbNCC, maNV;

    public frmNhapKho() {
        initComponents();
    }

    public frmNhapKho(String maNV1, String tenNV1) {
        initComponents();
        maNV = maNV1;
        jlbXinChao.setText("Xin chào, " + tenNV1);
        loadCbbNCC();
        loadCbbSP();
        getDataBan(listNK);

    }

    frmNhapKho(String tenNV) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void reset() {
        txtGia.setText("");
        txtSoLuong.setText("");
        getDataBan(listNK);
        index = -1;
    }

    public int demSoHoaDon() {
        try {
            int dem = 0;
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select count(*) from ChiTietNhapKho ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                dem = Integer.parseInt(rs.getString(1));
            }
            conn.close();
            return dem;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
            return -1;
        }
    }

    public void capnhatSLVaGia(String maSP, int soLuong, int gia) {
        try {
            float giaB = (float) (gia * 1.2);
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String update = "Update SanPham SET SoLuong= " + soLuong + ", GiaNhap=" + gia + ", GiaBan=" + giaB + " where MaSP= '" + maSP + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(update);
            rs = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Cập nhật số lượng và giá thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi");
            e.printStackTrace();
        }
    }

    public void luuCTNhapKHo(int maNK, String thoiGian, String maNV, String thongTin, int tongTien) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String insert = "INSERT INTO ChiTietNhapKho VALUES(" + maNK + ", '" + thoiGian + "', '" + maNV + "', N'" + thongTin + "', " + tongTien + ")";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(insert);
            rs = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Lưu Thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi lưu  không thành công");
            e.printStackTrace();
        }
    }

    public void luuNhapKHo(int maNK, String thoiGian, String maNV, String maSP, String tenSP, String tenNCC, int soLuong, int giaNhap, int thanhTien) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String insert = "INSERT INTO NhapKho VALUES(" + maNK + ", '" + thoiGian + "', '" + maNV + "', '" + maSP + "', N'" + tenSP + "', N'" + tenNCC + "', " + soLuong + ", " + giaNhap + ", " + thanhTien + ")";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(insert);
            rs = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi lưu NhapKho");
            e.printStackTrace();
        }
    }

    public void loadNCC() {
        listNCC.clear();
        listNCC = frmNCC.loadFile();
    }

    public void loadSPFull() {
        listSPFull.clear();
        listSPFull = frmSP.loadFile();
    }

    //Lấy ds sp theo từng ncc
    public void loadSP(String maCbbNCC) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from SanPham where MaNCC like '%" + maCbbNCC + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7));
                listSP.add(sp);
            }
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Không lấy dc SP");
            e.printStackTrace();

        }
    }

    public void loadCbbNCC() {
        listNCC.clear();
        loadNCC();
        for (NCC ncc : listNCC) {
            cbbNCC.addItem(ncc.getTenNCC().trim());
        }
    }

    public void loadCbbSP() {
        cbbSP.removeAllItems();
        String tenCbbNCC = cbbNCC.getSelectedItem().toString();
        for (NCC ncc : listNCC) {
            if (tenCbbNCC.trim().equals(ncc.getTenNCC().trim())) {
                maCbbNCC = ncc.getMaNCC().trim();
                break;
            }
        }
        listSP.clear();
        loadSP(maCbbNCC.trim());

        for (SanPham sp : listSP) {
            cbbSP.addItem(sp.getTenSP().trim());
        }
    }

    private void getDataBan(ArrayList<SanPham> listNK) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Tên NCC");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá nhập");
        defaultTableModel.addColumn("Thành tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp
        for (SanPham obj : listNK) {

            Vector vector = new Vector();
            vector.add(layTenNCC(obj.getMaNCC()));
            vector.add(obj.getTenSP());
            vector.add(obj.getSoLuong());
            vector.add(formatTien.format(obj.getGiaNhap()));
            vector.add(formatTien.format(obj.getSoLuong() * obj.getGiaNhap()));

            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }

        //thêm các thuộc tính đã lưu vào bảng
        jTable1.setModel(defaultTableModel);

    }

    public String layTenNCC(String maNCC) {
        String ten = "";
        listNCC.clear();
        loadNCC();
        for (NCC sp : listNCC) {
            if (maNCC.trim().equals(sp.getMaNCC().trim())) {
                ten = sp.getTenNCC().trim();
                break;
            }
        }
        return ten;
    }

    public String layMaNCC(String tenNCC) {
        String ma = "";
        for (NCC sp : listNCC) {
            if (tenNCC.equals(sp.getTenNCC())) {
                ma = sp.getMaNCC().trim();
            }
        }
        return ma;
    }

    public String layMaSP(String tenSP) {
        String ma = "";
        for (SanPham sp : listSP) {
            if (tenSP.equals(sp.getTenSP())) {
                ma = sp.getMaSP().trim();
            }
        }
        return ma;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cbbNCC = new javax.swing.JComboBox<>();
        btnThem = new javax.swing.JButton();
        cbbSP = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        txtGia = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        btnLuu = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        jlbTongTien = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jlbXinChao = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setPreferredSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel11.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbbNCC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbNCC.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbNCCItemStateChanged(evt);
            }
        });
        jPanel2.add(cbbNCC, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 62, 260, -1));

        btnThem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/add1.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });
        jPanel2.add(btnThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 61, -1, -1));

        cbbSP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(cbbSP, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 111, 260, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Tên sản phẩm");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Số lượng");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 167, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Giá");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 215, -1, -1));

        txtSoLuong.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(txtSoLuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 164, 260, -1));

        txtGia.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(txtGia, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 212, 260, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("(vnđ)");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(516, 219, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 258, 613, 163));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Tổng tiền");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 440, -1, -1));

        btnLuu.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnLuu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/tick.png"))); // NOI18N
        btnLuu.setText("Lưu");
        btnLuu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuuActionPerformed(evt);
            }
        });
        jPanel2.add(btnLuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(605, 486, 80, 40));

        btnXoa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/delete_24px.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });
        jPanel2.add(btnXoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 163, 90, 40));

        btnSua.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pencil_drawing_24px.png"))); // NOI18N
        btnSua.setText("Sửa");
        btnSua.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });
        jPanel2.add(btnSua, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 110, 90, 40));

        jlbTongTien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(jlbTongTien, new org.netbeans.lib.awtextra.AbsoluteConstraints(425, 439, 170, 22));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("(vnđ)");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(613, 443, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Nhà cung cấp");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 65, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 60, 760, 550));

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jlbXinChao.setForeground(new java.awt.Color(51, 0, 51));
        jPanel1.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 250, 40));

        jLabel1.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" Lady’s house");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 60));

        add(jPanel1);
        jPanel1.setBounds(580, 120, 765, 612);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel10);
        jLabel10.setBounds(0, 0, 1970, 980);
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        index = jTable1.getSelectedRow();
        cbbNCC.setSelectedItem(layTenNCC(listNK.get(index).getMaNCC()));
        cbbSP.setSelectedItem(listNK.get(index).getTenSP());
        txtGia.setText(String.valueOf(listNK.get(index).getGiaNhap()));
        txtSoLuong.setText(String.valueOf(listNK.get(index).getSoLuong()));
    }//GEN-LAST:event_jTable1MouseClicked

    private void cbbNCCItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbNCCItemStateChanged
        // TODO add your handling code here:
        loadCbbSP();
    }//GEN-LAST:event_cbbNCCItemStateChanged

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        String maSP = "", tenSP = "", tenNCC = "";
        int soLuong = 0, giaNhap = 0;
        tenNCC = cbbNCC.getSelectedItem().toString().trim();
        tenSP = cbbSP.getSelectedItem().toString().trim();
        maSP = layMaSP(tenSP);

        int giaBan = (int) (giaNhap * 1.2);

        String maNCC = layMaNCC(tenNCC);

        if (txtGia.getText().trim().equals("") || txtSoLuong.getText().trim().equals("")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ số lượng và giá!");
        } else {
            if (kt.ktc(txtGia.getText()) == false || kt.ktc(txtSoLuong.getText()) == false) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập số!");

            } else {
                soLuong = Integer.parseInt(txtSoLuong.getText().trim());
                giaNhap = Integer.parseInt(txtGia.getText().trim());
                int kiemtra = 0;
                int vitri = 0;

                for (int i = 0; i < listNK.size(); i++) {
                    if (listNK.get(i).getMaSP().trim().equals(maSP)) {
                        kiemtra = 1;
                        vitri = i;
                        break;
                    }
                }
                if (kiemtra == 0) {
                    SanPham nKho = new SanPham(maSP, tenSP, maNCC, giaNhap, giaBan, soLuong);
                    listNK.add(nKho);
                    for (SanPham sp : listNK) {
                        tongtien += sp.getGiaNhap() * sp.getSoLuong();
                    }

                    jlbTongTien.setText(String.valueOf(tongtien));
                    tongtien = 0;
                    reset();
                } else {
                    soLuong += listNK.get(vitri).getSoLuong();

                    SanPham nKho = new SanPham(maSP, tenSP, maNCC, giaNhap, giaBan, soLuong);
                    listNK.remove(vitri);
                    listNK.add(vitri, nKho);
                    for (SanPham sp : listNK) {
                        tongtien += sp.getGiaNhap() * sp.getSoLuong();
                    }
                    jlbTongTien.setText(String.valueOf(tongtien));
                    tongtien = 0;
                    reset();
                }
            }
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        String maSP = "", tenSP = "", tenNCC = "";
        int soLuong = 0, giaNhap = 0, thanhTien = 0;

        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hàng để sửa!");
        } else {
            if (txtGia.getText().trim().equals("") || txtSoLuong.getText().trim().equals("")) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ số lượng và giá!");
            } else {
                if (kt.ktc(txtGia.getText()) == false || kt.ktc(txtSoLuong.getText()) == false) {
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập số cho số lượng và giá!");
                } else {
                    tenNCC = cbbNCC.getSelectedItem().toString().trim();
                    tenSP = cbbSP.getSelectedItem().toString().trim();
                    maSP = layMaSP(tenSP);
                    soLuong = Integer.parseInt(txtSoLuong.getText().trim());
                    giaNhap = Integer.parseInt(txtGia.getText().trim());
                    String maNCC = layMaNCC(tenNCC);
                    int giaBan = (int) (giaNhap * 1.2);

                    SanPham nKho = new SanPham(maSP, tenSP, maNCC, giaNhap, giaBan, soLuong);
                    listNK.remove(index);
                    listNK.add(index, nKho);
                    for (SanPham sp : listNK) {
                        tongtien += sp.getGiaNhap() * sp.getSoLuong();
                    }
                    jlbTongTien.setText(String.valueOf(tongtien));
                    tongtien = 0;
                    reset();
                }
            }
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        if (listNK.size() == 0) {
            JOptionPane.showMessageDialog(this, "Danh sách chưa có sản phẩm nào!");
        } else {
            if (index == -1) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hàng để xóa!");
            } else {
                listNK.remove(index);
                JOptionPane.showMessageDialog(this, "Xóa thành công!");
                for (SanPham sp : listNK) {
                    tongtien += sp.getGiaNhap() * sp.getSoLuong();
                }
                jlbTongTien.setText(String.valueOf(tongtien));
                tongtien = 0;
                reset();
            }
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnLuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuuActionPerformed
        // TODO add your handling code here:
        Date date = new Date();
        // định dạng ngày tháng + giờ
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        if (listNK.size() == 0) {
            JOptionPane.showMessageDialog(this, "Danh sách rỗng!");
        } else {
            int maNK = demSoHoaDon() + 1;
            String thoiGian = sdf.format(date);
            //mã nhân viên có rồi.
            String thongtin = "";
            int tongT = 0;
            for (SanPham nk : listNK) {
                thongtin += nk.getMaSP() + "\t" + nk.getTenSP() + "\t" + nk.getSoLuong() + "\t" + nk.getGiaNhap() + "\t" + nk.getSoLuong() * nk.getGiaNhap() + "\n";
                tongT += nk.getSoLuong() * nk.getGiaNhap();
            }
            //Lưu chi tiết nhập kho
            luuCTNhapKHo(maNK, thoiGian, maNV, thongtin, tongT);
            //Dùng 2 vòng for để cập nhật số lượng
            for (SanPham nk : listNK) {
                int slcu = 0;
                listSPFull.clear();
                //Lấy ds tất cả sp
                loadSPFull();
                //Để so sánh masp nhập kho vs sp trong kho nếu trùng thì lấy ra sl cũ
                for (SanPham sp : listSPFull) {
                    if (nk.getMaSP().trim().equals(sp.getMaSP().trim())) {
                        slcu = sp.getSoLuong();
                    }
                }
                //Cộng số lượng cũ với sl nhập kho 
                int slmoi = slcu + nk.getSoLuong();
                //Lưu nhập kho
                luuNhapKHo(maNK, thoiGian, maNV, nk.getMaSP(), nk.getTenSP(), layTenNCC(nk.getMaNCC()), nk.getSoLuong(), nk.getGiaNhap(), nk.getSoLuong() * nk.getGiaNhap());
                //Cập nhật số lượng và giá
                capnhatSLVaGia(nk.getMaSP(), slmoi, nk.getGiaNhap());
            }
            listNK.clear();
            reset();
            jlbTongTien.setText("");
        }
    }//GEN-LAST:event_btnLuuActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLuu;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cbbNCC;
    private javax.swing.JComboBox<String> cbbSP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel jlbTongTien;
    private javax.swing.JLabel jlbXinChao;
    private javax.swing.JTextField txtGia;
    private javax.swing.JTextField txtSoLuong;
    // End of variables declaration//GEN-END:variables
}
