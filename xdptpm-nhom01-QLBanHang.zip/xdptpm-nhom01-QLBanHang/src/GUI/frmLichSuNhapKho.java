/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NhanVien;
import OBJ.SanPham;
import Utils.Conn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmLichSuNhapKho extends javax.swing.JPanel {

    /**
     * Creates new form frmLichSuNhapKho
     */
    NumberFormat formatTien = new DecimalFormat("###,###");
    DefaultTableModel defaultTableModel;
    String thoigian = "", maNV = "";
    int tongtien = 0;

    ArrayList<SanPham> listSP = new ArrayList<>();
    ArrayList<NhanVien> listNV = new ArrayList<>();
    
    public frmLichSuNhapKho(String tenNV) {
        initComponents();
        txtXinChao.setText("Xin chào, "+tenNV);
        loadCbbDot();
    }

    public void loadCbbDot() {
        for (int i = 0; i < demSoHoaDon(); i++) {
            cbbDot.addItem(String.valueOf(i + 1));
        }
    }

    public int demSoHoaDon() {
        try {
            int dem = 0;
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select count(*) from ChiTietNhapKho ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                dem = Integer.parseInt(rs.getString(1));
            }
            conn.close();
            return dem;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
            return -1;
        }
    }
    
     public void loadThongTin(String dot) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from ChiTietNhapKho where MaNK='" + dot + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                thoigian = rs.getString(2);
                maNV = rs.getString(3);
                tongtien = Integer.parseInt(rs.getString(5));
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }
     
      //Lấy ds sp của từng đợt nhập kho
    public void loadSP(String dot) {
        try {
            listSP.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from NhapKho where MaNK='" + dot + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham(rs.getString(4), rs.getString(5), rs.getString(6), Integer.parseInt(rs.getString(7)), Integer.parseInt(rs.getString(8)));
                listSP.add(sp);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }
    
    //Gọi đối tượng nhân viên từ bảng nhân viên để lấy ds nv
    frmNhanVien frmNV = new frmNhanVien();

    public void loadNV() {
        listNV.clear();
        listNV=frmNV.loadFile();
    }

    public String layTenNV(String manv) {
        String ten = "";
        loadNV();
        for (NhanVien nv : listNV) {
            if (manv.trim().equals(nv.getMaNV().trim())) {
                ten = nv.getTenNV();
                break;
            }
        }
        return ten;
    }

     //Hiển thị ds tương ứng với từng đợt
    private void getDataBan(ArrayList<SanPham> listNK) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Mã NCC");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá nhập");
        defaultTableModel.addColumn("Thành tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp
        for (SanPham obj : listSP) {
            
            Vector vector = new Vector();
            vector.add(obj.getMaSP().trim());
            vector.add(obj.getTenSP());
            vector.add(obj.getMaNCC());
            vector.add(obj.getSoLuong());
            vector.add(formatTien.format(obj.getGiaNhap()));
            vector.add(formatTien.format(obj.getSoLuong() * obj.getGiaNhap()));
            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable1.setModel(defaultTableModel);
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbbDot = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtThoiGian = new javax.swing.JTextField();
        txtMaNV = new javax.swing.JTextField();
        txtTenNV = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTongTien = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        txtXinChao = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setPreferredSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel10.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Đợt:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 67, -1, -1));

        cbbDot.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbDot.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbbDotItemStateChanged(evt);
            }
        });
        jPanel3.add(cbbDot, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 64, 197, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Thời gian:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 106, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Mã NV:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 152, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Tên NV:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 198, -1, -1));

        txtThoiGian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtThoiGian.setEnabled(false);
        jPanel3.add(txtThoiGian, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 103, 197, -1));

        txtMaNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtMaNV.setEnabled(false);
        jPanel3.add(txtMaNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 149, 197, -1));

        txtTenNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtTenNV.setEnabled(false);
        jPanel3.add(txtTenNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 195, 197, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Tổng tiền:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 244, -1, -1));

        txtTongTien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtTongTien.setEnabled(false);
        jPanel3.add(txtTongTien, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 241, 197, -1));

        jTable1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setEnabled(false);
        jScrollPane1.setViewportView(jTable1);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, 512, 134));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Chi tiết nhập kho");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 67, -1, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 60, 1080, 410));

        txtXinChao.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txtXinChao.setForeground(new java.awt.Color(51, 0, 51));
        jPanel2.add(txtXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 390, 40));

        jLabel8.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText(" Lady’s house");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 60));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, 1070, 471));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        jLabel7.setText("jLabel7");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1980, 980));

        add(jPanel1);
        jPanel1.setBounds(0, 0, 1980, 977);
    }// </editor-fold>//GEN-END:initComponents

    private void cbbDotItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbbDotItemStateChanged
        // TODO add your handling code here:
        loadThongTin(cbbDot.getSelectedItem().toString());
        txtThoiGian.setText(thoigian);
        txtMaNV.setText(maNV);
        txtTongTien.setText(String.valueOf(tongtien));
        txtTenNV.setText(layTenNV(maNV));
        loadSP(cbbDot.getSelectedItem().toString());
        getDataBan(listSP);
    }//GEN-LAST:event_cbbDotItemStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbbDot;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtTenNV;
    private javax.swing.JTextField txtThoiGian;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JLabel txtXinChao;
    // End of variables declaration//GEN-END:variables
}
