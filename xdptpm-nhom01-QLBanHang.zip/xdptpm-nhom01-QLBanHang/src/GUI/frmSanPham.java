/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.NCC;
import OBJ.SanPham;
import Utils.Conn;
import Utils.KTSo;
import Utils.KichThuocData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmSanPham extends javax.swing.JPanel {

    /**
     * Creates new form frmSanPham
     */
    NumberFormat formatTien = new DecimalFormat("###,###");
    frmDangNhap frm = new frmDangNhap();
    KTSo ktc = new KTSo();
    KichThuocData ktmax = new KichThuocData();
    private DefaultTableModel defaultTableModel;
    SanPham sp = new SanPham();
    int index = -1;
    String tdn;
    ArrayList<SanPham> listSP = new ArrayList<>();
    ArrayList<SanPham> listTK = new ArrayList<>();
    ArrayList<NCC> listNCC = new ArrayList<>();

    public frmSanPham(String tenNV) {
        initComponents();
        loadFile();
        getData(listSP);
        jlbXinChao.setText("Xin chào, " + tenNV);
        listNCC.clear();

//     b1   loadListNCC(); lấy dc 1 ds
        cbbNCC();//b2  load ds lên cbb
        txtGiaBan.setEditable(false);
    }

    public frmSanPham() {
        initComponents();
    }
//Kiểm tra kích thước của dữ liệu nhập

    public boolean kt() {
        boolean kq = true;
        if (txtMaSP.getText().length() > ktmax.layKichThuoc("sanpham", "masp")) {
            JOptionPane.showMessageDialog(this, "Mã sản phẩm không được nhập quá " + ktmax.layKichThuoc("sanpham", "masp") + " kí tự!");
            kq = false;
        } else {
            if (txtDvi.getText().length() > ktmax.layKichThuoc("sanpham", "dvtinh")) {
                JOptionPane.showMessageDialog(this, "Đơn vị tính không được nhập quá " + ktmax.layKichThuoc("sanpham", "dvtinh") + " kí tự!");
                kq = false;
            } else {
                if (txtTenSP.getText().length() > ktmax.layKichThuoc("sanpham", "tensp")) {
                    JOptionPane.showMessageDialog(this, "Tên sản phẩm không được nhập quá " + ktmax.layKichThuoc("sanpham", "tensp") + " kí tự!");
                    kq = false;
                } else {
                    kq = true;
                }
            }
        }
        return kq;
    }

    public void reset() {
        txtMaSP.setText("");
        txtTenSP.setText("");
        txtDvi.setText("");
        txtSoLuong.setText("");
        txtGiaNhap.setText("");
        txtGiaBan.setText("");
        listSP.clear();
        listNCC.clear();
        cbbNCC.removeAllItems();
        loadListNCC();
        loadFile();
        getData(listSP);
        cbbNCC();
        btlThem.setVisible(true);
        index = -1;
        txtGiaBan.setEditable(false);
        txtMaSP.setEditable(true);
    }

    //Lấy dữ liệu từ nhà cung cấp hiển thị lên cbb
    public void cbbNCC() {
        listNCC.clear();
        loadListNCC();
        for (NCC ncc : listNCC) {
            cbbNCC.addItem(ncc.getTenNCC().trim());
        }
    }

    public void loadListNCC() {

        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from NCC";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                NCC nsx = new NCC(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                listNCC.add(nsx);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    public ArrayList<SanPham> loadFile() {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả 
            String query = "Select * from SanPham";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham(rs.getString(1).trim(), rs.getString(2).trim(), rs.getString(3).trim(), rs.getString(4).trim(), rs.getInt(5), rs.getInt(6), rs.getInt(7));
                listSP.add(sp);
            }
            conn.close();
            return listSP;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            return null;
        }
    }

    // hiển thị danh sách lên bảng
    private void getData(ArrayList<SanPham> listSP) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Tên NCC");
        defaultTableModel.addColumn("Đơn vị tính");
        defaultTableModel.addColumn("Giá nhập");
        defaultTableModel.addColumn("Giá bán");
        defaultTableModel.addColumn("Số lượng");

        //thêm dữ liệu của từng cột của bảng từ listSP
        for (SanPham obj : listSP) {
            Vector vector = new Vector();
            vector.add(obj.getMaSP());
            vector.add(obj.getTenSP());
            vector.add(layTenNCC(obj.getMaNCC()));
            vector.add(obj.getDonVT());
            vector.add(formatTien.format(obj.getGiaNhap()));
            vector.add(formatTien.format(obj.getGiaBan()));
            vector.add(formatTien.format(obj.getSoLuong()));
            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable2.setModel(defaultTableModel);

    }

    public String layTenNCC(String maNCC) {
        String tenNCC = "";
        listNCC.clear();
        loadListNCC();
        for (int i = 0; i < listNCC.size(); i++) {
            if (listNCC.get(i).getMaNCC().trim().equals(maNCC)) {
                tenNCC = listNCC.get(i).getTenNCC();
                break;
            }
        }
        return tenNCC;
    }

    public String layNCCTuTen(String ten) {
        String ma = "";
        for (NCC ncc : listNCC) {
            if (ten.trim().equals(ncc.getTenNCC().trim())) {
                ma = ncc.getMaNCC();
                break;
            }
        }
        return ma;
    }

    public void them(String maSP, String tenSP, String maNCC, String donVT) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            String insert = "INSERT INTO SanPham values('" + maSP + "', N'" + tenSP + "', '" + maNCC + "', N'" + donVT + "', " + 0 + ", " + 0 + ", " + 0 + " )";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(insert);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Thêm thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Thêm không thành công!");
            e.printStackTrace();
        }
    }

    public void sua(String maSP, String tenSP, String maNCC, String dvTinh, int giaBan) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs;
            String update = "Update SanPham SET TenSP= N'" + tenSP.trim() + "', MaNCC='" + maNCC.trim() + "', DVTinh=N'" + dvTinh.trim() + "', GiaBan = " + giaBan + "  where MaSP= '" + maSP.trim() + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(update);
            rs = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Sửa thông tin sản phẩm thành công");
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sửa thông tin sản phẩm không thành công");
            e.printStackTrace();
        }
    }

    public void xoa(String caicanxoa) {
        try {
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            int rs; // kết quả
            String query = "delete from SanPham where MaSP = '" + caicanxoa + "'   ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(this, "Xoá thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Xóa không thành công do sản phẩm ràng buộc với hóa đơn!");
        }
    }

    public void timkiem(String caicantim) {
        try {
            listTK.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from SanPham where TenSP like N'%" + caicantim + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7));
                listTK.add(sp);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        txtTimkiem = new javax.swing.JTextField();
        btlTimKiem = new javax.swing.JButton();
        btlXoa = new javax.swing.JButton();
        btlThem = new javax.swing.JButton();
        btlSua = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JTextField();
        txtDvi = new javax.swing.JTextField();
        txtGiaNhap = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        txtTenSP = new javax.swing.JTextField();
        txtGiaBan = new javax.swing.JTextField();
        cbbNCC = new javax.swing.JComboBox<>();
        btlThoat = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jlbXinChao = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 204, 204));
        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel10.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel5);
        jPanel5.setBounds(0, 850, 1920, 60);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setToolTipText("");
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tìm kiếm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24), new java.awt.Color(255, 0, 0))); // NOI18N

        txtTimkiem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        btlTimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search_24px.png"))); // NOI18N
        btlTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(txtTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btlTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btlTimKiem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 90, 540, 90));

        btlXoa.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_24px.png"))); // NOI18N
        btlXoa.setText("Xóa");
        btlXoa.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlXoa.setMaximumSize(new java.awt.Dimension(100, 35));
        btlXoa.setMinimumSize(new java.awt.Dimension(100, 35));
        btlXoa.setPreferredSize(new java.awt.Dimension(100, 35));
        btlXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlXoaActionPerformed(evt);
            }
        });
        jPanel2.add(btlXoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 220, 200, 50));

        btlThem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add_user_male_24px.png"))); // NOI18N
        btlThem.setText("Thêm");
        btlThem.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThem.setPreferredSize(new java.awt.Dimension(100, 35));
        btlThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThemActionPerformed(evt);
            }
        });
        jPanel2.add(btlThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 220, 200, 50));

        btlSua.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pencil_drawing_24px.png"))); // NOI18N
        btlSua.setText("Sửa");
        btlSua.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlSua.setMaximumSize(new java.awt.Dimension(100, 35));
        btlSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlSuaActionPerformed(evt);
            }
        });
        jPanel2.add(btlSua, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 290, 200, 50));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thông tin sản phẩm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24), new java.awt.Color(255, 0, 0))); // NOI18N
        jPanel3.setToolTipText("Thông tin sản phẩm");
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Đơn vị tính");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Giá nhập");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Số lượng");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Tên sản phẩm");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Tên NCC");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("Giá bán");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("Mã sản phẩm");

        txtMaSP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        txtDvi.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        txtGiaNhap.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtGiaNhap.setEnabled(false);

        txtSoLuong.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtSoLuong.setEnabled(false);

        txtTenSP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        txtGiaBan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        cbbNCC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDvi, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTenSP)
                            .addComponent(cbbNCC, 0, 186, Short.MAX_VALUE)
                            .addComponent(txtGiaBan)))
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDvi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(cbbNCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)
                        .addComponent(txtGiaBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 720, -1));

        btlThoat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btlThoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit_24px.png"))); // NOI18N
        btlThoat.setText("Reset");
        btlThoat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btlThoat.setPreferredSize(new java.awt.Dimension(100, 35));
        btlThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlThoatActionPerformed(evt);
            }
        });
        jPanel2.add(btlThoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 290, 200, 50));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 1310, 230));

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        jPanel2.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 310, 40));

        jLabel1.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" Lady’s house");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1330, 70));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1330, 650));

        add(jPanel1);
        jPanel1.setBounds(290, 110, 1330, 650);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel2);
        jLabel2.setBounds(0, 0, 1930, 990);
    }// </editor-fold>//GEN-END:initComponents

    private void btlThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThemActionPerformed
        // TODO add your handling code here:
        String tenNCC, maNCC = "";
        //Lấy tên ncc từ Cbb và lấy mã ncc từ tên
        tenNCC = cbbNCC.getSelectedItem().toString();
        maNCC = layNCCTuTen(tenNCC).trim();

        if (txtMaSP.getText().trim().equals("") || txtDvi.getText().trim().equals("") || txtTenSP.getText().trim().equals("")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đủ thông tin sản phẩm!");
        } else {
            if (kt() == false) {

            } else {
                int kt = 0;
                for (SanPham sp : listSP) {
                    if (sp.maSP.trim().equals(txtMaSP.getText().trim())) {
                        kt = 1;
                    }
                }
                if (kt == 1) {
                    JOptionPane.showMessageDialog(this, "Mã này đã được sử dụng!");
                } else {
                    them(maNCC + "-" + txtMaSP.getText().trim(), txtTenSP.getText().trim(), maNCC, txtDvi.getText().trim());
                    reset();
                }
            }
        }
    }//GEN-LAST:event_btlThemActionPerformed

    private void btlTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlTimKiemActionPerformed
        // TODO add your handling code here:
        listTK.clear();
        String caicantim = txtTimkiem.getText().trim();

        if (caicantim.equals("")) {
            getData(listSP);
        } else {
            timkiem(caicantim);
            if (listTK.size() == 0) {
                JOptionPane.showMessageDialog(this, "Không có SP nào liên quan!");
            } else {
                getData(listTK);
            }
        }
    }//GEN-LAST:event_btlTimKiemActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i = jTable2.getSelectedRow();
        SanPham s = listSP.get(i);
        txtMaSP.setText(s.getMaSP());
        txtTenSP.setText(s.getTenSP());
        txtDvi.setText(s.getDonVT());
        cbbNCC.setSelectedItem(layTenNCC(s.getMaNCC()));
        txtGiaBan.setText(Integer.toString(s.getGiaBan()));
        txtGiaNhap.setText(Integer.toString(s.getGiaNhap()));
        txtSoLuong.setText(Integer.toString(s.getSoLuong()));

        index = i;

        txtMaSP.setEditable(false);
        txtGiaBan.setEditable(true);
    }//GEN-LAST:event_jTable2MouseClicked

    private void btlSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlSuaActionPerformed
        // TODO add your handling code here:
        String tenNCC, maNCC;
        //Lấy tên ncc từ Cbb và lấy mã ncc từ tên
        tenNCC = cbbNCC.getSelectedItem().toString();
        maNCC = layNCCTuTen(tenNCC);
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn hàng để sửa!");
        } else {
            if (txtDvi.getText().trim().equals("") || txtTenSP.getText().trim().equals("")) {
                JOptionPane.showMessageDialog(this, "Vui long nhập đủ thông tin sản phẩm!");
            } else {
                if (kt() == false) {

                } else {
                    if (Integer.parseInt(txtGiaBan.getText().trim()) <= Integer.parseInt(txtGiaNhap.getText().trim())) {
                        JOptionPane.showMessageDialog(this, "Giá bán phải lớn hơn giá nhập!");
                    } else {
                        sua(txtMaSP.getText(), txtTenSP.getText(), maNCC, txtDvi.getText(), Integer.parseInt(txtGiaBan.getText().trim()));
                        reset();
                    }
                }
            }
        }
    }//GEN-LAST:event_btlSuaActionPerformed

    private void btlXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlXoaActionPerformed
        // TODO add your handling code here:
        if (index < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần xóa!");
        } else {
            String caicanxoa = listSP.get(index).getMaSP();
            xoa(caicanxoa);
            reset();
        }
    }//GEN-LAST:event_btlXoaActionPerformed

    private void btlThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlThoatActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btlThoatActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btlSua;
    private javax.swing.JButton btlThem;
    private javax.swing.JButton btlThoat;
    private javax.swing.JButton btlTimKiem;
    private javax.swing.JButton btlXoa;
    private javax.swing.JComboBox<String> cbbNCC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel jlbXinChao;
    private javax.swing.JTextField txtDvi;
    private javax.swing.JTextField txtGiaBan;
    private javax.swing.JTextField txtGiaNhap;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSP;
    private javax.swing.JTextField txtTimkiem;
    // End of variables declaration//GEN-END:variables
}
