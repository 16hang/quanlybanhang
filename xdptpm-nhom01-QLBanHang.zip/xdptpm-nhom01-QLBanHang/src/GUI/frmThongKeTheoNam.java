/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import OBJ.CTHoaDon;
import OBJ.NhanVien;
import OBJ.SanPham;
import Utils.Conn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class frmThongKeTheoNam extends javax.swing.JPanel {

    NumberFormat formatTien = new DecimalFormat("###,###");
    private DefaultTableModel defaultTableModel;
    ArrayList<CTHoaDon> listCTHD = new ArrayList<>();
    ArrayList<NhanVien> listNV = new ArrayList<>();
    ArrayList<SanPham> listSP = new ArrayList<>();
    ArrayList<SanPham> listSPHD = new ArrayList<>();

    /**
     * Creates new form frmThongKeTheoNam
     */
    public frmThongKeTheoNam(String tenNV) {
        initComponents();
        jlbXinChao.setText("Xin Chào, "+tenNV);
        loadCbb();
        loadListSP();
    }

    public void loadCbb() {
        cbbNV.removeAllItems();;
        cbbNV.addItem("Tất cả");
        listNV.clear();
        loadListNV();
        for (NhanVien a : listNV) {
            cbbNV.addItem(a.getMaNV());
        }
    }

    //Gọi đối tượng bảng nhân viên để lấy ds nhân viên
    frmNhanVien frmNV = new frmNhanVien();

    public void loadListNV() {
        listNV.clear();
        listNV = frmNV.loadFile();
    }

    //Gọi đối tượng bảng sản phẩm để lấy ds sản phẩm
    frmSanPham frmSP = new frmSanPham();

    public void loadListSP() {
        listSP.clear();
        listSP = frmSP.loadFile();
    }

    //Lấy ds hóa đơn theo năm
    public void layDSHD(String caicantim1) {
        try {
            listCTHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from ChiTietHoaDon where NgayBan like '%" + caicantim1 + "%' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                CTHoaDon hd = new CTHoaDon(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(5));
                listCTHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Lấy ds các sản phẩm trong hóa đơn
    public void layDSSP(String caicantim) {
        try {
            listSPHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from HoaDon where MaHD = '" + caicantim.trim() + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                SanPham hd = new SanPham(rs.getString(4), rs.getInt(5), rs.getInt(6));
                listSPHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Lấy ds hóa đơn theo năm và mã nhân viên
    public void layDSHDNV(String caicantim1, String manv) {
        try {
            listCTHD.clear();
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select * from ChiTietHoaDon where NgayBan like '%" + caicantim1 + "%' and MaNV = '" + manv + "' ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                CTHoaDon hd = new CTHoaDon(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(5));
                listCTHD.add(hd);
            }
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "KO kết nối dc");
            e.printStackTrace();
        }
    }

    //Hiển thị ds các hóa đơn
    private void getListHD(ArrayList<CTHoaDon> listCTHD) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã DH");
        defaultTableModel.addColumn("Mã NV");
        defaultTableModel.addColumn("Ngáy bán");
        defaultTableModel.addColumn("Tổng tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp

        for (CTHoaDon hd : listCTHD) {
            Vector vector = new Vector();
            vector.add(hd.getMaHD());
            vector.add(hd.getMaNV());
            vector.add(hd.getNgayBan());
            vector.add(formatTien.format(hd.getTong()));

            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }

        //thêm các thuộc tính đã lưu vào bảng
        jTable1.setModel(defaultTableModel);

    }

    //Hiển thị ds các  sản phẩm có trong hóa đơn
    private void getThongTin(ArrayList<SanPham> listSPHD) {
        //tạo 1 cái bảng rỗng
        defaultTableModel = new DefaultTableModel();
        // tên các cột của bảng
        defaultTableModel.addColumn("Mã SP");
        defaultTableModel.addColumn("Tên SP");
        defaultTableModel.addColumn("Mã NCC");
        defaultTableModel.addColumn("Số lượng");
        defaultTableModel.addColumn("Giá bán");
        defaultTableModel.addColumn("Tổng tiền");
        //thêm dữ liệu của từng cột của bảng từ listsp
        for (SanPham sp : listSPHD) {
            Vector vector = new Vector();
            vector.add(sp.getMaSP());
            vector.add(layTenSP(sp.getMaSP()));
            vector.add(layMaNCC(sp.getMaSP()));
            vector.add(sp.getSoLuong());
            vector.add(formatTien.format(sp.getGiaBan()));
            vector.add(formatTien.format(sp.getSoLuong() * sp.getGiaBan()));
            //lưu các thuộc tính của từng hàng
            defaultTableModel.addRow(vector);
        }
        //thêm các thuộc tính đã lưu vào bảng
        jTable2.setModel(defaultTableModel);

    }

    public String layTenSP(String maSP) {
        String ten = "";
        listSP.clear();
        loadListSP();
        for (SanPham sp : listSP) {
            if (maSP.trim().equals(sp.getMaSP().trim())) {
                ten = sp.getTenSP();
                break;
            }
        }
        return ten;
    }

    public String layMaNCC(String maSP) {
        String mancc = "";
        listSP.clear();
        loadListSP();
        for (SanPham sp : listSP) {
            if (maSP.trim().equals(sp.getMaSP().trim())) {
                mancc = sp.getMaNCC();
                break;
            }
        }
        return mancc;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jlbXinChao = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnThongKe = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jlbTongTien = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Jnam = new com.toedter.calendar.JYearChooser();
        jLabel1 = new javax.swing.JLabel();
        cbbNV = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1915, 977));
        setMinimumSize(new java.awt.Dimension(1915, 977));
        setLayout(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jLabel8.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Địa chỉ: 27 Đào Nguyên, Trâu Quỳ-Gia Lâm-Hà nội ---------Hỗ trợ :0979992999");

        jLabel11.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Thiết kế bởi: Nhóm phát triển phần mềm 2HLN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 1886, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        add(jPanel4);
        jPanel4.setBounds(0, 850, 1920, 60);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlbXinChao.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        jPanel2.add(jlbXinChao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 309, 40));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnThongKe.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnThongKe.setText("Thống kê");
        btnThongKe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeActionPerformed(evt);
            }
        });
        jPanel1.add(btnThongKe, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Nhân viên");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.setDragEnabled(true);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, 490, 190));

        jlbTongTien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(jlbTongTien, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, 180, 30));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable2.setEnabled(false);
        jScrollPane2.setViewportView(jTable2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 670, 150));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Tổng tiền:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("(vnđ)");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 60, 30));
        jPanel1.add(Jnam, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 70, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Năm");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        cbbNV.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cbbNV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        jPanel1.add(cbbNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 150, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("Danh sách hóa đơn");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 51, 51));
        jLabel7.setText("Chi tiết hóa đơn");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, -1, -1));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 970, 560));

        jLabel9.setBackground(new java.awt.Color(204, 204, 255));
        jLabel9.setFont(new java.awt.Font("Informal Roman", 3, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText(" Lady’s house");
        jLabel9.setOpaque(true);
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 70));

        add(jPanel2);
        jPanel2.setBounds(470, 110, 968, 621);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/nensiuthi2.png"))); // NOI18N
        add(jLabel5);
        jLabel5.setBounds(0, 0, 1920, 980);
    }// </editor-fold>//GEN-END:initComponents

    private void btnThongKeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeActionPerformed
        // TODO add your handling code here:
        String nam = String.valueOf(Jnam.getYear()).trim();
        if (cbbNV.getSelectedItem().toString().trim().equals("Tất cả")) {
            layDSHD(nam);
            getListHD(listCTHD);
            int tt = 0;
            for (CTHoaDon ct : listCTHD) {
                tt += ct.getTong();
            }
            jlbTongTien.setText(String.valueOf(formatTien.format(tt)));
        } else {
            layDSHDNV(nam, cbbNV.getSelectedItem().toString().trim());
            getListHD(listCTHD);
            int tt = 0;
            for (CTHoaDon ct : listCTHD) {
                tt += ct.getTong();
            }
            jlbTongTien.setText(String.valueOf(formatTien.format(tt)));
        }
        listSPHD.clear();
        getThongTin(listSPHD);
    }//GEN-LAST:event_btnThongKeActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int i = jTable1.getSelectedRow();
        String tkim = listCTHD.get(i).getMaHD();
        layDSSP(tkim);
        getThongTin(listSPHD);
    }//GEN-LAST:event_jTable1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JYearChooser Jnam;
    private javax.swing.JButton btnThongKe;
    private javax.swing.JComboBox<String> cbbNV;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel jlbTongTien;
    private javax.swing.JLabel jlbXinChao;
    // End of variables declaration//GEN-END:variables
}
