/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Admin
 */
public class KichThuocData {
    public int layKichThuoc(String a, String b){
        try {
            int dem = 0;
            Connection conn = null; // tạo kết nối
            PreparedStatement ps = null; //chứa câu lệnh truy vấn
            ResultSet rs = null; // kết quả
            String query = "Select COL_LENGTH('"+a+" ', '"+b+"') ";
            conn = new Conn().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                dem = Integer.parseInt(rs.getString(1))/2;
            }
            conn.close();
            return dem;
        } catch (Exception e) {
            
            e.printStackTrace();
            return -1;
        }
    }
}
