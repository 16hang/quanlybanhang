/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

/**
 *
 * @author Admin
 */
public class KTSo {
    // kiểm tra trong số lượng và đơn giá không được có chữ
    public boolean ktc(String a) {
        String b[] = a.split("");
        for (String x : b) {
            if (!x.equals("0") && !x.equals("1") && !x.equals("2") && !x.equals("3") && !x.equals("4") && !x.equals("5") && !x.equals("6") && !x.equals("7") && !x.equals("8") && !x.equals("9")) {
                return false;
            }
        }
        return true;
    }
}
