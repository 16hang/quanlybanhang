/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

/**
 *
 * @author Admin
 */
public class KTSdt {
    public boolean testsdt(String a){
        String[] c= a.split("");
            if (c[0].equals("0")) {
                return true;
            }else{
                return false;
            }
    }
}
